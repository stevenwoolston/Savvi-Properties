<?php
/**
 * The blank file - Silence is golden.
 *
 * @package Logistico
 * @since 1.0
 * @version 1.0
 */

 